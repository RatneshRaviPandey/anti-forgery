using System;
using System.IO;

class Program
{
    static int Main(string[] args)
    {
        if (args.Length < 2)
        {
            PrintUsage();
            return 1;
        }

        string command = args[0].ToLowerInvariant();
        string inputPath = args[1];
        string? outputPath = args.Length >= 3 ? args[2] : null;

        switch (command)
        {
            case "encode":
                return EncodeZipToBase64(inputPath, outputPath);
            case "decode":
                return DecodeBase64ToZip(inputPath, outputPath);
            default:
                Console.Error.WriteLine($"Unknown command: {command}");
                PrintUsage();
                return 1;
        }
    }

    static int EncodeZipToBase64(string zipPath, string? outputPath)
    {
        if (!File.Exists(zipPath))
        {
            Console.Error.WriteLine($"File not found: {zipPath}");
            return 1;
        }

        outputPath ??= Path.ChangeExtension(zipPath, ".txt");

        byte[] zipBytes = File.ReadAllBytes(zipPath);
        string base64 = Convert.ToBase64String(zipBytes);
        File.WriteAllText(outputPath, base64);

        Console.WriteLine($"Encoded: {zipPath}");
        Console.WriteLine($"Output:  {outputPath}");
        Console.WriteLine($"Size:    {zipBytes.Length:N0} bytes -> {base64.Length:N0} chars");
        return 0;
    }

    static int DecodeBase64ToZip(string base64Path, string? outputPath)
    {
        if (!File.Exists(base64Path))
        {
            Console.Error.WriteLine($"File not found: {base64Path}");
            return 1;
        }

        outputPath ??= Path.ChangeExtension(base64Path, ".zip");

        string base64 = File.ReadAllText(base64Path).Trim();
        byte[] zipBytes = Convert.FromBase64String(base64);
        File.WriteAllBytes(outputPath, zipBytes);

        Console.WriteLine($"Decoded: {base64Path}");
        Console.WriteLine($"Output:  {outputPath}");
        Console.WriteLine($"Size:    {base64.Length:N0} chars -> {zipBytes.Length:N0} bytes");
        return 0;
    }

    static void PrintUsage()
    {
        Console.WriteLine("ZipBase64Converter - Convert .zip files to/from Base64");
        Console.WriteLine();
        Console.WriteLine("Usage:");
        Console.WriteLine("  ZipBase64Converter encode <input.zip> [output.txt]");
        Console.WriteLine("  ZipBase64Converter decode <input.txt> [output.zip]");
        Console.WriteLine();
        Console.WriteLine("Examples:");
        Console.WriteLine("  ZipBase64Converter encode myfile.zip");
        Console.WriteLine("  ZipBase64Converter encode myfile.zip encoded.txt");
        Console.WriteLine("  ZipBase64Converter decode encoded.txt");
        Console.WriteLine("  ZipBase64Converter decode encoded.txt restored.zip");
    }
}
